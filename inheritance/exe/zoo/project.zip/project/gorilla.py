# from inheritance.exe.zoo.project.mammal import Mammal
from project.mammal import Mammal


class Gorilla(Mammal):
    pass
