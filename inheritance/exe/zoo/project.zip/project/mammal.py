# from inheritance.exe.zoo.project.animal import Animal
from project.animal import Animal


class Mammal(Animal):
    pass


