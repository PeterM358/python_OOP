from project.reptile import Reptile
# from inheritance.exe.zoo.project.reptile import Reptile


class Lizard(Reptile):
    pass
